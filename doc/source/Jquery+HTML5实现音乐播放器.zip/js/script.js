﻿(function($){
var repeat = localStorage.repeat || 0,
shuffle = localStorage.shuffle || 'false',
continous = true,
autoplay = true,
playlist = [
{
title: '肩上蝶',
artist: '金志文',
album: '肩上蝶',
cover:'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/10504925422628832.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/jianshangdie.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/jianshangdie.ogg'
},
{
title: 'The Truth that you leave',
artist: '炎亚纶',
album: 'The Truth that you leave',
cover:'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/yanyalun.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/TheTruththatyouleave.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/TheTruththatyouleave.ogg'
},
{
title: '我可以抱你吗',
artist: '张惠妹',
album: '我可以抱你吗',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/132731360220331_4.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/wokeyibaonima.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/wokeyibaonima.ogg'
},
{
title: '一万个舍不得',
artist: '庄心妍',
album: '一万个舍不得',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/20130325084808733.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/yiwangeshebude.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/yiwangeshebude.ogg'
},
{
title: '我们的歌谣',
artist: 'TRY',
album: '我们的歌谣',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/try.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/womendegeyao.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/music/womendegeyao.ogg'
},
{
title: '西海情歌',
artist: '刀郎',
album: '西海情歌',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/30634_420420.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/xihaiqingge.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/xihaiqingge.ogg'
},
{
title: '愿得一人心',
artist: '李行亮',
album: '愿得一人心',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/rdn_5087372d82b84.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/yuandeyirenxin.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/yuandeyirenxin.ogg'
},
{
title: '把悲伤留给自己',
artist: '刘若英',
album: '把悲伤留给自己',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/1044055242-0.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/babeishangliugeiziji.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/babeishangliugeiziji.ogg'
},
{
title: '不再犹豫',
artist: 'BEYOND',
album: '不再犹豫',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/beyond.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/buzaiyouyu.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/buzaiyouyu.ogg'
},
{
title: 'Bye Bye',
artist: 'Mariah Carey',
album: 'Bye Bye',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/byebye.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/ByeBye.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/ByeBye.ogg'
},
{
title: '小爱情',
artist: '梁静茹',
album: '小爱情',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/liangjinru.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/xiaoaiqing.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/xiaoaiqing.ogg'
},
{
title: '明天,你好',
artist: '牛奶咖啡',
album: '明天,你好',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/niunaikafei.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/mingtiannihao.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/mingtiannihao.ogg'
},
{
title: '我很好',
artist: '杨千嬅',
album: '我很好',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/yangqianhua.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/wohenhao.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/wohenhao.ogg'
},
{
title: '给我一个吻',
artist: '罗文',
album: '给我一个吻',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/luowen.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/geiwoyigewen.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/geiwoyigewen.ogg'
},
{
title: '日光-苏打绿',
artist: '苏打绿',
album: '日光',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/sudalv.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/riguang.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/riguang.ogg'
},
{
title: '王力宏 - Forever Love',
artist: '王力宏',
album: 'Forever Love',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/wanglihong.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/ForeverLove.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/ForeverLove.ogg'
},
{
title: 'I Love You',
artist: '王若琳',
album: 'I Love You',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/wangruolin.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/ILoveYou.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/ILoveYou.ogg'
},
{
title: '无地自容',
artist: '周晓鸥',
album: '无地自容',
cover: 'http://dxsn.gongzuo.in/bowen/HTML5player/css/images/zhouxiaoou.jpg',
mp3: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/wudizhirong.mp3',
ogg: 'http://dxsn.gongzuo.in/bowen/HTML5player/UserMusic/wudizhirong.ogg'
},
];

	// Load playlist
	for (var i=0; i<playlist.length; i++){
		var item = playlist[i];
		$('#playlist').append('<li>'+item.artist+' - '+item.title+'</li>');
	}

	var time = new Date(),
		currentTrack = shuffle === 'true' ? time.getTime() % playlist.length : 0,
		trigger = false,
		audio, timeout, isPlaying, playCounts;

	var play = function(){
		audio.play();
		$('.playback').addClass('playing');
		timeout = setInterval(updateProgress, 500);
		isPlaying = true;
	}

	var pause = function(){
		audio.pause();
		$('.playback').removeClass('playing');
		clearInterval(updateProgress);
		isPlaying = false;
	}

	// Update progress
	var setProgress = function(value){
		var currentSec = parseInt(value%60) < 10 ? '0' + parseInt(value%60) : parseInt(value%60),
			ratio = value / audio.duration * 100;

		$('.timer').html(parseInt(value/60)+':'+currentSec);
		$('.progress .pace').css('width', ratio + '%');
		$('.progress .slider a').css('left', ratio + '%');
	}

	var updateProgress = function(){
		setProgress(audio.currentTime);
	}

	// Progress slider
	$('.progress .slider').slider({step: 0.1, slide: function(event, ui){
		$(this).addClass('enable');
		setProgress(audio.duration * ui.value / 100);
		clearInterval(timeout);
	}, stop: function(event, ui){
		audio.currentTime = audio.duration * ui.value / 100;
		$(this).removeClass('enable');
		timeout = setInterval(updateProgress, 500);
	}});

	// Volume slider
	var setVolume = function(value){
		audio.volume = localStorage.volume = value;
		$('.volume .pace').css('width', value * 100 + '%');
		$('.volume .slider a').css('left', value * 100 + '%');
	}

	var volume = localStorage.volume || 0.5;
	$('.volume .slider').slider({max: 1, min: 0, step: 0.01, value: volume, slide: function(event, ui){
		setVolume(ui.value);
		$(this).addClass('enable');
		$('.mute').removeClass('enable');
	}, stop: function(){
		$(this).removeClass('enable');
	}}).children('.pace').css('width', volume * 100 + '%');

	$('.mute').click(function(){
		if ($(this).hasClass('enable')){
			setVolume($(this).data('volume'));
			$(this).removeClass('enable');
		} else {
			$(this).data('volume', audio.volume).addClass('enable');
			setVolume(0);
		}
	});

	// Switch track
	var switchTrack = function(i){
		if (i < 0){
			track = currentTrack = playlist.length - 1;
		} else if (i >= playlist.length){
			track = currentTrack = 0;
		} else {
			track = i;
		}

		$('audio').remove();
		loadMusic(track);
		if (isPlaying == true) play();
	}

	// Shuffle
	var shufflePlay = function(){
		var time = new Date(),
			lastTrack = currentTrack;
		currentTrack = time.getTime() % playlist.length;
		if (lastTrack == currentTrack) ++currentTrack;
		switchTrack(currentTrack);
	}

	// Fire when track ended
	var ended = function(){
		pause();
		audio.currentTime = 0;
		playCounts++;
		if (continous == true) isPlaying = true;
		if (repeat == 1){
			play();
		} else {
			if (shuffle === 'true'){
				shufflePlay();
			} else {
				if (repeat == 2){
					switchTrack(++currentTrack);
				} else {
					if (currentTrack < playlist.length) switchTrack(++currentTrack);
				}
			}
		}
	}

	var beforeLoad = function(){
		var endVal = this.seekable && this.seekable.length ? this.seekable.end(0) : 0;
		$('.progress .loaded').css('width', (100 / (this.duration || 1) * endVal) +'%');
	}

	// Fire when track loaded completely
	var afterLoad = function(){
		if (autoplay == true) play();
	}

	// Load track
	var loadMusic = function(i){
		var item = playlist[i],
			newaudio = $('<audio>').html('<source src="'+item.mp3+'"><source src="'+item.ogg+'">').appendTo('#player');
		$('.cover').html('<img src="'+item.cover+'" alt="'+item.album+'">');
		$('.tag').html('<strong>'+item.title+'</strong><span class="artist">'+item.artist+'</span><span class="album">'+item.album+'</span>');
		$('#playlist li').removeClass('playing').eq(i).addClass('playing');
		audio = newaudio[0];
		audio.volume = $('.mute').hasClass('enable') ? 0 : volume;
		audio.addEventListener('progress', beforeLoad, false);
		audio.addEventListener('durationchange', beforeLoad, false);
		audio.addEventListener('canplay', afterLoad, false);
		audio.addEventListener('ended', ended, false);
	}

	loadMusic(currentTrack);
	$('.playback').on('click', function(){
		if ($(this).hasClass('playing')){
			pause();
		} else {
			play();
		}
	});
	$('.rewind').on('click', function(){
		if (shuffle === 'true'){
			shufflePlay();
		} else {
			switchTrack(--currentTrack);
		}
	});
	$('.fastforward').on('click', function(){
		if (shuffle === 'true'){
			shufflePlay();
		} else {
			switchTrack(++currentTrack);
		}
	});
	$('#playlist li').each(function(i){
		var _i = i;
		$(this).on('click', function(){
			switchTrack(_i);
		});
	});

	if (shuffle === 'true') $('.shuffle').addClass('enable');
	if (repeat == 1){
		$('.repeat').addClass('once');
	} else if (repeat == 2){
		$('.repeat').addClass('all');
	}

	$('.repeat').on('click', function(){
		if ($(this).hasClass('once')){
			repeat = localStorage.repeat = 2;
			$(this).removeClass('once').addClass('all');
		} else if ($(this).hasClass('all')){
			repeat = localStorage.repeat = 0;
			$(this).removeClass('all');
		} else {
			repeat = localStorage.repeat = 1;
			$(this).addClass('once');
		}
	});

	$('.shuffle').on('click', function(){
		if ($(this).hasClass('enable')){
			shuffle = localStorage.shuffle = 'false';
			$(this).removeClass('enable');
		} else {
			shuffle = localStorage.shuffle = 'true';
			$(this).addClass('enable');
		}
	});
})(jQuery);